print(f'Initializing package {__name__}')

name = "sentio_prober_control"