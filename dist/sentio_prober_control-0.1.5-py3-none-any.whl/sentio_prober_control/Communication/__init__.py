print(f'Initializing package {__name__}')

