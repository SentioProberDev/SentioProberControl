from enum import Enum


class GpibCardVendor(Enum):
    Adlink = 0,
    NationalInstruments = 1
